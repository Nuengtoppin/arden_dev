//! Vector map (semantic skeleton) — stub
#[derive(Default)]
pub struct VectorMap;