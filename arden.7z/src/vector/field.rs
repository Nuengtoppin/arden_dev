//! Vector field container — stub
#[derive(Default)]
pub struct VectorField;